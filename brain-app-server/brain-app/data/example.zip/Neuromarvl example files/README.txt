A complete dataset requires 4 files. They can have any name, and minimal examples are provided here as a starting point.

The 'coordinates.txt' file contains the physiological coordinates of the areas (or nodes) in the brain which the data sets correspond to.

The 'labels.txt' file is optional, and contains the names of these nodes.

The 'matrix.txt' file contain the matrix of measured similarities (in activity) between these nodes for each data set.

The 'attributes.txt' files contain attributes for each node in each data set.

